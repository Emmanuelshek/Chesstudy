// Shared constants for all pages
window.PIECES = {
  p:"https://upload.wikimedia.org/wikipedia/commons/c/c7/Chess_pdt45.svg",
  r:"https://upload.wikimedia.org/wikipedia/commons/f/ff/Chess_rdt45.svg",
  n:"https://upload.wikimedia.org/wikipedia/commons/e/ef/Chess_ndt45.svg",
  b:"https://upload.wikimedia.org/wikipedia/commons/9/98/Chess_bdt45.svg",
  q:"https://upload.wikimedia.org/wikipedia/commons/4/47/Chess_qdt45.svg",
  k:"https://upload.wikimedia.org/wikipedia/commons/f/f0/Chess_kdt45.svg",
  P:"https://upload.wikimedia.org/wikipedia/commons/4/45/Chess_plt45.svg",
  R:"https://upload.wikimedia.org/wikipedia/commons/7/72/Chess_rlt45.svg",
  N:"https://upload.wikimedia.org/wikipedia/commons/7/70/Chess_nlt45.svg",
  B:"https://upload.wikimedia.org/wikipedia/commons/b/b1/Chess_blt45.svg",
  Q:"https://upload.wikimedia.org/wikipedia/commons/1/15/Chess_qlt45.svg",
  K:"https://upload.wikimedia.org/wikipedia/commons/4/42/Chess_klt45.svg",
};

// Sidebar nav (plan-aware). Reads /api/me; if not signed in, no sidebar is rendered.
window.PLAN_RANK = { free: 0, unlimited: 1, super: 2 };
window.renderNav = async function(active) {
  let me = null;
  try { me = (await (await fetch("/api/me")).json()).user; } catch {}
  if (!me) return; // public pages don't get a sidebar
  const myRank = PLAN_RANK[me.plan || "free"];
  const items = [
    { href: "/play",      label: "Play vs Bot", key: "play",      icon: "♞", min: 0 },
    { href: "/openings",  label: "Openings",    key: "openings",  icon: "📖", min: 0 },
    { href: "/classroom", label: "Classroom",   key: "classroom", icon: "🎓", min: 0 },
    { href: "/groups",    label: "Groups",      key: "groups",    icon: "💬", min: 0 },
    { href: "/review",    label: "Game Review", key: "review",    icon: "🔍", min: 1 },
    { href: "/ai",        label: "Chess AI",    key: "ai",        icon: "🤖", min: 2 },
  ];
  const planLabel = me.plan === "super" ? "⚡ Super Unlimited" : me.plan === "unlimited" ? "⚡ Unlimited" : "Free plan";
  const html = `
    <aside id="nav">
      <div class="brand">♟ Chesstudy</div>
      ${items.map(i => {
        const locked = myRank < i.min;
        const cls = (i.key === active ? "active " : "") + (locked ? "locked" : "");
        const need = i.min === 1 ? "unlimited" : "super";
        const href = locked ? `/subscribe?need=${need}` : i.href;
        return `<a href="${href}" class="${cls.trim()}" title="${locked ? 'Upgrade required' : ''}"><span class="icon">${i.icon}</span>${i.label}${locked ? '<span class="lock">🔒</span>' : ''}</a>`;
      }).join("")}
      <div class="nav-foot">
        <div class="who">${escapeHtml(me.name)}</div>
        <a href="/subscribe" class="plan-pill">${planLabel}</a>
        <a href="#" id="nav-logout" class="logout">Sign out</a>
      </div>
    </aside>`;
  document.body.insertAdjacentHTML("afterbegin", html);
  document.getElementById("nav-logout").addEventListener("click", async (e) => {
    e.preventDefault();
    await fetch("/api/logout", { method: "POST" });
    location.href = "/";
  });
  function escapeHtml(s){return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
};
